/*   1  */  typedef struct {
/*   2  */      char data[4096];
/*   3  */      int key;
/*   4  */  } item;
/*   5  */  
/*   6  */  item array[] = {
/*   7  */      {"bill", 3},
/*   8  */      {"neil", 4},
/*   9  */      {"john", 2},
/*  10  */      {"rick", 5},
/*  11  */      {"alex", 1},
/*  12  */  };
/*  13  */  
/*  14  */  sort(a,n)
/*  15  */  item *a; 
/*  16  */  { 
/*  17  */      int i = 0, j = 0;
/*  18  */      int s = 1;
/*  19  */  
/*  20  */      for(; i < n && s != 0; i++) {
/*  21  */              s = 0;
/*  22  */              for(j = 0; j < n-1; j++) {
/*  23  */                      if(a[j].key > a[j+1].key) {
/*  24  */                              item t = a[j];
/*  25  */                              a[j] = a[j+1];
/*  26  */                              a[j+1] = t;
/*  27  */                              s++;
/*  28  */                      }
/*  29  */              }
/*  30  */              n--;
/*  31  */      }
/*  32  */  }
/*  33  */  
/*  34  */  main()
/*  35  */  {
/*  36  */          int i;
/*  37  */          sort(array,5); 
/*  38  */          for(i = 0; i < 5; i++)
/*  39  */                  printf("array[%d] = {%s, %d}\n",
/*  40  */                          i, array[i].data, array[i].key);
/*  41  */  }
