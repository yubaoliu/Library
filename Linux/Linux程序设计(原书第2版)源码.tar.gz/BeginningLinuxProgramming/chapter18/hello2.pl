#!/usr/bin/perl -w
# hello2.pl

$message = "Hello, World\n";
print $message;
