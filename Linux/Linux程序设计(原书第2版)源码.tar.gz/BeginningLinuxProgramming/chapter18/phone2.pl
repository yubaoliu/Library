#!/usr/bin/perl -w

%phonebook = ( "Bob" => "247305", "Phil" => "205832", "Sara" => "226010" );
print "Sara's phone number is $phonebook{Sara}\n";
print "Bob's phone number is $phonebook{Bob}\n";
